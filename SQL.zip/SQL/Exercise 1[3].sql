--Execrise 1.3
/*3.	Select a list of FirstName and LastName for
employees where Title is one of Design Engineer, Tool Designer or Marketing Assistant.
(Schema(s) involved: HumanResources, Person)*/
SELECT Person.Person.FirstName, Person.Person.LastName,
HumanResources.Employee.JobTitle
FROM Person.Person
INNER JOIN
HumanResources.Employee
ON
Person.Person.BusinessEntityID = HumanResources.Employee.BusinessEntityID
WHERE JobTitle = 'Design Engineer' OR JobTitle = 'Tool Designer' OR JobTitle = 'Marketing Assistant'