/*

Create a function that takes as inputs a SalesOrderID, 
a Currency Code, and a date, and returns a table of all the 
SalesOrderDetail rows for that Sales Order including Quantity,
ProductID, UnitPrice, and the unit price converted to the 
target currency based on the end of day rate for the date provided.
Exchange rates can be found in the Sales.CurrencyRate table. ( Use AdventureWorks)


*/
GO 
Create FUNCTION Sales.UfnSalesOrderDetails 
	(@NewSalesOrderID int, @NewCurrencyCode nchar, @NewDate datetime)
	RETURNS @NewSalesOrderDetails TABLE(SalesOrderID int, OrderQty int, ProductID int, UnitPrice money)
AS 
	BEGIN 
		INSERT @NewSalesOrderDetails
		SELECT SalesOrderID, OrderQty, ProductID, UnitPrice FROM Sales.SalesOrderDetail
		WHERE SalesOrderID = @NewSalesOrderID;
	RETURN
END;

GO
SELECT * FROM Sales.UfnSalesOrderDetails(43659,'USD',2005-07-01);

GO
CREATE FUNCTION ConvertUnitPrice(@NewSalesOrderID INT, @NewCurrencyCode NCHAR(3), @NewDate DATETIME)
RETURNS TABLE
AS
    RETURN 
        SELECT SalesOrderID,OrderQty,ProductID,UnitPrice,UnitPrice *(SELECT EndOfDayRate FROM Sales.CurrencyRate
          WHERE ToCurrencyCode = @NewCurrencyCode and ModifiedDate = @NewDate) AS UnitConversion
        FROM Sales.SalesOrderDetail
        WHERE SalesOrderID = @NewSalesOrderID;