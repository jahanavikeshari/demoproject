--1
/*1.	Display the number of records in the [SalesPerson] table.
(Schema(s) involved: Sales)*/
SELECT COUNT(*) FROM [Sales].[SalesPerson]
--2
/*2.	Select both the FirstName and LastName of records
from the Person table where the FirstName begins with the letter �B�.
(Schema(s) involved: Person)*/
SELECT [FirstName],[LastName] FROM [Person].[Person] WHERE [FirstName] LIKE 'B%'

/*4.	Display the Name and Color of the Product with the maximum weight.
(Schema(s) involved: Production)*/
--4
SELECT  [Name],[Color] 
FROM [Production].[Product]
WHERE [Production].[Product].[Weight] = (SELECT MAX([Production].[Product].[Weight]) FROM [Production].[Product])

