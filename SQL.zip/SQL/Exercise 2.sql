--Execrise 2
/*
Write separate queries using a join, a subquery, 
a CTE, and then an EXISTS to list all AdventureWorks
customers who have not placed an order.
*/

SELECT * FROM [Sales].[Customer] AS c
LEFT OUTER JOIN [Sales].[SalesOrderHeader] AS s
ON c.CustomerID = s.CustomerID
WHERE s.SalesOrderID is NULL

SELECT * FROM [Sales].[Customer] AS c
WHERE
c.CustomerID in 
(SELECT s.CustomerID 
FROM [Sales].[SalesOrderHeader] AS s
WHERE s.SalesOrderID IS NULL)

WITH s AS (
SELECT SalesOrderID
FROM [Sales].[SalesOrderHeader]
)
SELECT * FROM Sales.Customer c
LEFT OUTER JOIN s ON c.CustomerID = s.SalesOrderID
WHERE s.SalesOrderID is NULL


SELECT * FROM Sales.Customer AS c 
WHERE EXISTS(SELECT * FROM [Sales].[SalesOrderHeader] 
AS s
WHERE s.SalesOrderID IS NULL AND c.CustomerID = s.CustomerID)
