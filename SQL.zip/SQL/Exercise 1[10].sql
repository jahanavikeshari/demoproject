/*10.	Display the ProductId of the product with the largest stock level.
Hint: Use the Scalar-valued function [dbo]. [UfnGetStock]. 
(Schema(s) involved: Production)*/

SELECT ProductID,Quantity FROM Production.ProductInventory
ORDER BY Quantity DESCn