--Execrise 1.7
/*7.	Display the FirstName and LastName of records from the Person
table where FirstName contains the letters �ss�. Display an additional
column with sequential numbers for each row returned beginning at integer 1.
(Schema(s) involved: Person)*/
SELECT FirstName,LastName,ROW_NUMBER() OVER
(ORDER BY FirstName ASC)AS RowNumber
FROM Person.Person
WHERE FirstName LIKE '%ss%'