/*
Write a trigger for the Product table to ensure the list
price can never be raised more than 15 Percent in a single change.
Modify the above trigger to execute its check code only if the 
ListPrice column is   updated (Use AdventureWorks Database).
*/

GO

CREATE TRIGGER UpdatePrice ON Production.Product 
FOR UPDATE
AS 
BEGIN

	DECLARE @oldPrice MONEY;
	DECLARE @newPrice MONEY;
	SELECT @oldPrice = ListPrice FROM deleted
	SELECT @newPrice = ListPrice FROM inserted

	IF(@newPrice > (@oldPrice + (@oldPrice*0.15)))
	BEGIN
		PRINT 'Price cannot be more than 15 percent of the old price.'
		Rollback
	END

END